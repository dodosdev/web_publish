export default function Person(){
    return (
    <div className="content-wrap">
        <h1>Person</h1> 
    </div>
    );
}