export default function MyPage(){
    return (
        <>
        <h1>MyPage</h1>
        </>
    );
}