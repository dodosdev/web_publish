export default function Admin() {
return (
    <div>
        
    </div>
    );
};