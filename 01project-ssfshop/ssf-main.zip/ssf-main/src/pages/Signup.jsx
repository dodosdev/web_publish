export default function Signup(){
    return (
        <>
        <div className="content-wrap">
            <h1>Signup</h1> 
        </div>
        </>
    );
}