export default function Rank({children}){
    return (
        <>
        {children}
        </>
    );
}