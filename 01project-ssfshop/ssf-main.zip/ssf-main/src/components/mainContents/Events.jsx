export default function Events({children}){
    return (
        <>
        {children}
        </>
    );
}