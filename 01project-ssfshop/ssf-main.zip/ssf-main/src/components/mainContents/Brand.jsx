export default function Brand({children}){
    return (
        <>
        {children}
        </>
    );
}