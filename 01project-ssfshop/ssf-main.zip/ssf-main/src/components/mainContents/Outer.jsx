export default function Outer({children}){
    return (
        <>
        {children}
        </>
    );
}