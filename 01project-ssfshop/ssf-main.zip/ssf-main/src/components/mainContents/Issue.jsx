export default function Issue({children}){
    return (
        <>
        {children}
        </>
    );
}