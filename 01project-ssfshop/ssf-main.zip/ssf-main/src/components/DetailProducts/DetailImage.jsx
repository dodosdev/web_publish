export default function DetailImage(){
    return (
        <div class="godsImg-area">
        <div class="preview-thumb" id="godImgThumb">
            <div class="thumb-item active" data="/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg">
                    <button type="button">
                        <img src="https://img.ssfshop.com/cmd/RB_100x133/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg" onerror="javascript:this.src='/v3/images/common/noImg_477.gif'" alt=""/>
                    </button>
                </div>
                <div class="thumb-item" data="/goods/ORBR/24/10/14/GPDN24101477500_1_THNAIL_ORGINL_20241023161548815.jpg">
                    <button type="button">
                        <img src="https://img.ssfshop.com/cmd/RB_100x133/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_1_THNAIL_ORGINL_20241023161548815.jpg" onerror="javascript:this.src='/v3/images/common/noImg_477.gif'" alt=""/>
                    </button>
                </div>
                <div class="thumb-item" data="/goods/ORBR/24/10/14/GPDN24101477500_2_THNAIL_ORGINL_20241023161548815.jpg">
                    <button type="button">
                        <img src="https://img.ssfshop.com/cmd/RB_100x133/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_2_THNAIL_ORGINL_20241023161548815.jpg" onerror="javascript:this.src='/v3/images/common/noImg_477.gif'" alt=""/>
                    </button>
                </div>
                </div>
        <div class="preview-img">
            <div class="img-wrap" id="godImgWrap">
                <div class="img-item active" data="/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg">
                            <img src="https://img.ssfshop.com/cmd/LB_750x1000/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg" data-zoom="https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg"/>
                        </div>
                        <div class="img-item" data="/goods/ORBR/24/10/14/GPDN24101477500_1_THNAIL_ORGINL_20241023161548815.jpg">
                            <img src="https://img.ssfshop.com/cmd/LB_750x1000/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_1_THNAIL_ORGINL_20241023161548815.jpg" data-zoom="https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_1_THNAIL_ORGINL_20241023161548815.jpg"/>
                        </div>
                        <div class="img-item" data="/goods/ORBR/24/10/14/GPDN24101477500_2_THNAIL_ORGINL_20241023161548815.jpg">
                            <img src="https://img.ssfshop.com/cmd/LB_750x1000/src/https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_2_THNAIL_ORGINL_20241023161548815.jpg" data-zoom="https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_2_THNAIL_ORGINL_20241023161548815.jpg"/>
                        </div>
                        </div>
            <div class="preview-lens" style={{"left": "453px", "top": "606px", "width": "120.54px", "height": "147.784px"}}></div>
            <div class="preview-zoom" style={{"width": "630px", "background": 
            "url(&quot;https://img.ssfshop.com/goods/ORBR/24/10/14/GPDN24101477500_0_THNAIL_ORGINL_20241023161548815.jpg&quot;) -2367.6px -3136.94px / 3000px 3960px;"}}></div>
            <button type="button" class="preview-btn btn-prev disabled"></button>
            <button type="button" class="preview-btn btn-next"></button>
        </div>
    </div>
    );
}